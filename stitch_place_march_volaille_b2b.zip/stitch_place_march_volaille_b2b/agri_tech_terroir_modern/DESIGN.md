---
name: Agri-Tech Terroir Modern
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d8e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#404943'
  inverse-surface: '#263143'
  inverse-on-surface: '#ecf1ff'
  outline: '#707972'
  outline-variant: '#c0c9c1'
  surface-tint: '#30694c'
  primary: '#003b24'
  on-primary: '#ffffff'
  primary-container: '#185338'
  on-primary-container: '#8bc5a3'
  inverse-primary: '#98d4b0'
  secondary: '#895100'
  on-secondary: '#ffffff'
  secondary-container: '#fda12f'
  on-secondary-container: '#693d00'
  tertiary: '#601b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#862a01'
  on-tertiary-container: '#ffa181'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b4f0cb'
  primary-fixed-dim: '#98d4b0'
  on-primary-fixed: '#002112'
  on-primary-fixed-variant: '#155136'
  secondary-fixed: '#ffdcbd'
  secondary-fixed-dim: '#ffb86d'
  on-secondary-fixed: '#2c1600'
  on-secondary-fixed-variant: '#683c00'
  tertiary-fixed: '#ffdbcf'
  tertiary-fixed-dim: '#ffb59c'
  on-tertiary-fixed: '#390c00'
  on-tertiary-fixed-variant: '#822800'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d8e3fb'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: '0'
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: '0'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: '0'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: '0'
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  financial-number:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

Ce système de design incarne la convergence entre le dynamisme de la filière avicole ouest-africaine et la rigueur d'une infrastructure B2B numérique de pointe. Conçu pour relier couvoirs, provendiers, éleveurs de la presqu'île de Dakar et des Niayes, grossistes et chaînes de restauration (CHR), le style visuel s'articule autour d'un **Modernisme Terroir Tactile & Structuré**.

Loin de l'austérité clinique de la fintech classique ou du folklore agricole superficiel, l'interface évoque :
- **La fiabilité agronomique & commerciale :** Des lignes solides, des architectures de données nettes et une lisibilité absolue en plein soleil sur smartphone d'exploitation ou sur écran de bureau au comptoir logistique.
- **La chaleur du terroir sahélien :** Une palette inspirée du vert profond des feuillages d'acacia, de la terre cuite des pistes et du jaune maïs des moulins céréaliers, contrebalancée par des fonds ivoire doux et reposants.
- **La clarté contractuelle :** Une focalisation sur la clarté financière (transactions en Francs CFA BCEAO, délais d'échéance de crédit, solvabilité) et la traçabilité des lots (volailles de chair, poussins d'un jour, plateaux d'œufs).

## Colors

Le système repose sur un mode clair natif (`light`), optimisé pour la lisibilité diurne et le confort de lecture sous forte luminosité ambiante. 

### Rôles des couleurs :
- **Primary (`#185338`) & Primary Deep (`#0F3824`) :** Symbolisent la vitalité agricole, la prospérité des récoltes et la solidité de la plateforme. Utilisés pour les actions dominantes, les barres d'en-tête de synthèse et les métriques maîtresses.
- **Secondary (`#E28B15` / `#F59E0B`) :** Teinte or maïs et graine de mil, réservée aux alertes d'attention, aux transitions d'états d'inventaire, aux indicateurs d'échéance intermédiaire et aux boutons d'actions secondaires à fort impact.
- **Tertiary (`#A8421A`) :** Teinte latérite / terre cuite solaire, dédiée aux éléments nécessitant un ancrage physique, aux avertissements de rupture critique et aux litiges commerciaux.
- **Neutres & Surfaces :**
  - Fond de page / Toile : Crème ivoire doux (`#FDFBF7`) pour neutraliser la fatigue oculaire causée par les blancs purs.
  - Surface Conteneur / Cartes : Écru clair (`#FFFFFF`) avec bordures subtiles écru-sable (`#E8E2D5`).
  - Surface Neutre Surélevée : Beige lin (`#F4EFE6`) pour les tables de données et les sections secondaires.
  - Typographie & Contraste : Anthracite texturé (`#0F172A` pour les titres, `#1E293B` pour le corps de texte, `#64748B` pour les métadonnées).

### Couleurs sémantiques B2B :
- **Statuts Commandes :**
  - *Envoyée :* Bleu cobalt ardoise (`#2563EB` sur fond `#EFF6FF`).
  - *Confirmée :* Sarcelle profond (`#0D9488` sur fond `#F0FDFA`).
  - *En préparation :* Ambre maïs (`#D97706` sur fond `#FFFBEB`).
  - *Prête :* Olive dorée (`#65A30D` sur fond `#F7FEE7`).
  - *En livraison :* Indigo logistique (`#4F46E5` sur fond `#EEF2FF`).
  - *Livrée :* Vert champêtre (`#15803D` sur fond `#F0FDF4`).
  - *Litige / Rejet :* Rouge terreux piment (`#DC2626` sur fond `#FEF2F2`).

## Typography

La typographie marie l'ingénierie technique moderne avec une chaleur organique accessible :
- **Space Grotesk (Titres & Métriques financières) :** Apporte une assise géométrique percutante, particulièrement adaptée aux tableaux de bord logistiques, aux codes de lots d'abattage et aux montants en FCFA. L'alignement numérique tabulaire (`font-variant-numeric: tabular-nums`) est obligatoire pour toutes les colonnes financières et pondérales (kg, têtes, sacs d'aliment).
- **Plus Jakarta Sans (Corps de texte & Contrôles) :** Fournit une excellente lisibilité à petite échelle, des formes rondes chaleureuses et un confort visuel exceptionnel pour les contrats, formulaires de bons de commande et listes de contrôle vétérinaire.

### Normes de formatage monétaire (XOF / FCFA) :
- Les montants doivent toujours être groupés par séparateur d'espace insécable (ex: `1 250 000 FCFA` ou `18 500 F`).
- Le suffixe `FCFA` s'affiche avec la police de label semi-gras pour subordonner la devise à la valeur numérique.

## Layout & Spacing

Le système structure l'affichage selon une grille fluide à 12 colonnes (desktop), 8 colonnes (tablette) et 4 colonnes (mobile), articulée autour d'un rythme de base de 8px (sous-multiples de 4px autorisés pour les badges et bordures).

### Adaptabilité & Reflow :
- **Mobile (< 768px) :** Marges de toile serrées (`1rem`) pour maximiser l'espace utile. Les tables de données complexes adoptent un comportement hybride : bascule en cartes empilées pour les commandes individuelles, avec actions rapides (appel livreur, validation de réception) ancrées en bas d'écran (*bottom sheet / sticky action*).
- **Tablet (768px - 1024px) :** Vue modulaire avec volet latéral rétractable pour la navigation d'exploitation (lots, provende, santé animale).
- **Desktop (> 1024px) :** Largeur maximale de conteneur limitée à `1440px` centrée. Présentation dense type ERP avicole avec division écran 70/30 lors de l'inspection des détails de factures ou de traçabilité sanitaire.

## Elevation & Depth

L'élévation évite les ombres plastiques désincarnées et privilégie une superposition de matières inspirée de l'architecture moderne sahélienne : surfaces douces, contours minéraux texturés et ombres chaudes à faible diffusion.

1. **Niveau 0 (Toile de fond) :** Teinte crème mat `#FDFBF7`. Aucune ombre.
2. **Niveau 1 (Cartes de données, Tableaux B2B, Lignes d'inventaire) :** Fond `#FFFFFF`, bordure périmétrique fine de 1px en `#E8E2D5`. Ombre diffuse subtile : `box-shadow: 0 1px 3px rgba(30, 41, 59, 0.05), 0 1px 2px rgba(24, 83, 56, 0.02)`.
3. **Niveau 2 (Survol, Cartes interactives, Menus déroulants) :** Rehaussement tactile doux : `box-shadow: 0 4px 14px -2px rgba(24, 83, 56, 0.08), 0 2px 6px -1px rgba(30, 41, 59, 0.04)`.
4. **Niveau 3 (Modales de transaction, Bons de livraison, Tiroirs de filtres) :** Élévation franche avec délimiteur foncé : `box-shadow: 0 16px 32px -6px rgba(15, 56, 36, 0.16), 0 4px 12px -2px rgba(30, 41, 59, 0.08)`.
5. **Backdrop Blurs :** Utilisés avec parcimonie (`backdrop-filter: blur(8px)`) sur les en-têtes flottants et les tiroirs mobiles avec une opacité de 85% de la surface crème.

## Shapes

Le langage de formes s'appuie sur le niveau **Rounded (2)** :
- Les conteneurs standard, formulaires, cartes et blocs d'aperçu de commande adoptent un rayon de courbure de `0.5rem` (8px).
- Les cartes de bord de grande dimension et les modales utilisent `rounded-lg` (`1rem` / 16px).
- Les badges de statut d'acheminement, les pastilles d'alerte de stock et les tags de notation de crédit utilisent des formes capsules complètes (*pill-shaped* `9999px`) afin de trancher visuellement avec l'orthodoxie orthogonale des tables B2B.
- Les boutons d'action rapide et sélecteurs de quantité respectent `0.5rem` pour préserver une zone de frappe compacte et stable.

## Components

### Boutons
- **Primary :** Fond `#185338`, texte `#FFFFFF`, poids semi-bold (`600`). Au survol : assombrissement vers `#0F3824` avec micro-transition (150ms).
- **Secondary (Terroir Accent) :** Fond `#E28B15`, texte `#FFFFFF`. Réservé aux actions d'engagement commercial (ex: "Valider le bon d'enlèvement", "Octroyer le crédit").
- **Outline / Neutral :** Fond transparent, bordure 1.5px `#D6CEBE`, texte `#1E293B`. Au survol : fond `#F4EFE6`.
- **Hauteurs standardisées :** `44px` (tactile mobile/terrain) et `36px` (tableaux denses desktop).

### Badges de Statut (Workflow Avicole & Logistique)
Composants en pilule (`padding: 4px 10px`, typographie `label-sm`), accompagnés d'une puce circulaire de 6px colorée :
- **Envoyée :** Fond `#EFF6FF`, texte `#1D4ED8`, puce `#3B82F6`.
- **Confirmée :** Fond `#F0FDFA`, texte `#0F766E`, puce `#14B8A6`.
- **En préparation :** Fond `#FFFBEB`, texte `#B45309`, puce `#F59E0B`.
- **Prête :** Fond `#F7FEE7`, texte `#4D7C0F`, puce `#84CC16`.
- **En livraison :** Fond `#EEF2FF`, texte `#4338CA`, puce `#6366F1`.
- **Livrée :** Fond `#F0FDF4`, texte `#15803D`, puce `#22C55E`.
- **Litige :** Fond `#FEF2F2`, texte `#B91C1C`, puce `#EF4444`.

### Indicateurs de Stocks (Volailles vivantes, Calibrage, Aliments)
- Barres de jauge segmentées ou jauges linéaires combinant seuil critique (tampon de sécurité de 3 jours d'aliment ou quota de mortalité).
- **Code couleur d'inventaire :** Vert champêtre (> 40% capacité), Ambre maïs (15% - 40%), Rouge brique (< 15% rupture imminente).

### Métriques de Solvabilité & Crédit Éleveur
- **Jauge de Crédit / Scoring :** Bloc d'en-tête de compte composé d'une note de confiance (ex: `A+`, `B`, `C`), d'un ratio d'encours disponible en FCFA et d'un barre-graphe de limite autorisée avec code d'incitation (ex: "Éligible paiement à 30j après enlèvement").

### Champs de Saisie (Inputs)
- Fond `#FFFFFF`, bordure 1px `#D6CEBE`, coins arrondis de 8px.
- État actif (`focus`) : Contour renforcé de 2px en `#185338` avec halo transparent `rgba(24, 83, 56, 0.12)`.
- Intégration systématique de suffixes fixes pour les unités d'exploitation : `kg`, `sujets`, `alvéoles`, `FCFA`.

### Cartes & Listes
- Cartes de commande délimitées par une fine ligne supérieure de 3px reprenant la couleur du statut actuel.
- Tables de négociation B2B avec lignes alternées blanches et lin clair (`#FAF7F0`), garantissant une lecture sans chevauchement lors de l'inspection de bons multi-lignes.